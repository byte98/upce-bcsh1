﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SemestralProject.Visual
{
    /// <summary>
    /// Class representing some kind of icon
    /// </summary>
    internal class Icon
    {
        /// <summary>
        /// Name of icon
        /// </summary>
        public string Name { get; init; }

        /// <summary>
        /// Image representation of icon
        /// </summary>
        private Bitmap image;


        /// <summary>
        /// Creates new icon
        /// </summary>
        /// <param name="name">Name of icon</param>
        /// <param name="image">Path to file with image representing icon</param>
        public Icon(string name, string image)
        {
            this.Name = name;
            using(Stream stream = new FileStream(image, FileMode.Open, FileAccess.Read))
            {
                this.image = new Bitmap(stream);
            }
        }

        /// <summary>
        /// Displays icon in picture box
        /// </summary>
        /// <param name="pictureBox">Picture box in which icon will be displayed</param>
        public void Display(PictureBox pictureBox)
        {
            pictureBox.Image = (System.Drawing.Image)this.image;
        }

        /// <summary>
        /// Gets image representation of icon
        /// </summary>
        /// <returns>Image representation of icon</returns>
        public System.Drawing.Image GetImage()
        {
            return (System.Drawing.Image)this.image;
        }
    }
}
