﻿using SemestralProject.Utils;
using SemestralProject.Visual;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;
using System.Xml;
using Icon = SemestralProject.Visual.Icon;

namespace SemestralProject.Persistence
{
    /// <summary>
    /// Class representing exporter of current state of program into file
    /// </summary>
    internal class Exporter: AbstractProgress
    {
        /// <summary>
        /// Wrapper of all program resources
        /// </summary>
        private readonly Context context;

        /// <summary>
        /// Actuall progress of export
        /// </summary>
        private ushort progress = 0;

        /// <summary>
        /// Path to file to which data will be exported into
        /// </summary>
        public string OutputPath { private get; set; }


        /// <summary>
        /// Creates new class which performs export of current state of program into file
        /// </summary>
        /// <param name="context">Wrapper of all program resources which will be exported</param>
        public Exporter(Context context)
        {
            this.context = context;
            this.OutputPath = string.Empty;
        }

        /// <summary>
        /// Exports state of program into file
        /// </summary>
        private void Export()
        {
            this.progress = 0;
            this.OnProgress(new ProgressEventArgs(ushort.MaxValue, "Připravuji export dat..."));
            this.MakeExportDirectory();
        }

        /// <summary>
        /// Prepares directory where all exported data will be temporarily saved
        /// </summary>
        private void MakeExportDirectory()
        {
            string path = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_EXPORT";
            if (Directory.Exists(path))
            {
                Directory.Delete(path, true);
                this.OnProgressLog(new ProgressLogEventArgs("Smazán adresář " + path));
            }
            this.OnProgress(new ProgressEventArgs(this.progress, "Připravuji export dat..."));
            Directory.CreateDirectory(path);
            this.progress++;
            this.OnProgress(new ProgressEventArgs(this.progress, "Připravuji export dat..."));
            this.OnProgressLog(new ProgressLogEventArgs("Vytvořen adresář " + path));
            Directory.CreateDirectory(path + Path.DirectorySeparatorChar + "DB");
            this.progress++;
            this.OnProgress(new ProgressEventArgs(this.progress, "Připravuji export dat..."));
            this.OnProgressLog(new ProgressLogEventArgs("Vytvořen adresář " + path + Path.DirectorySeparatorChar + "DB"));
            Directory.CreateDirectory(path + Path.DirectorySeparatorChar + "ICONS");
            this.progress++;
            this.OnProgress(new ProgressEventArgs(this.progress, "Připravuji export dat..."));
            this.OnProgressLog(new ProgressLogEventArgs("Vytvořen adresář " + path + Path.DirectorySeparatorChar + "ICONS"));
            Directory.CreateDirectory(path + Path.DirectorySeparatorChar + "PICTURES");
            this.progress++;
            this.OnProgress(new ProgressEventArgs(this.progress, "Připravuji export dat..."));
            this.OnProgressLog(new ProgressLogEventArgs("Vytvořen adresář " + path + Path.DirectorySeparatorChar + "PICTURES"));
            Directory.CreateDirectory(path + Path.DirectorySeparatorChar + "DATAFILES");
            this.progress++;
            this.OnProgress(new ProgressEventArgs(this.progress, "Připravuji export dat..."));
            this.OnProgressLog(new ProgressLogEventArgs("Vytvořen adresář " + path + Path.DirectorySeparatorChar + "DATAFILES"));
        }

        /// <summary>
        /// Exports information systems
        /// (this can be called AFTER <see cref="Export(string)" !)/>
        /// </summary>
        private void ExportInformationSystems()
        {
            string input = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_DB" + Path.DirectorySeparatorChar + DataStorage.ISFile;
            string output = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_EXPORT" + Path.DirectorySeparatorChar + "DB" + Path.DirectorySeparatorChar + DataStorage.ISFile;
            this.OnProgress(new ProgressEventArgs(this.progress, "Exportuji informační systémy..."));
            File.Copy(input, output, true);
            this.OnProgressLog(new ProgressLogEventArgs("Zkopírován soubor " + input + " (" + output + ")"));
            this.progress += (40 / 5);
        }

        /// <summary>
        /// Exports maps
        /// (this can be called AFTER <see cref="Export(string)" !)/>
        /// </summary>
        private void ExportMaps()
        {
            string input = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_DB" + Path.DirectorySeparatorChar + DataStorage.MapFile;
            string output = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_EXPORT" + Path.DirectorySeparatorChar + "DB" + Path.DirectorySeparatorChar + DataStorage.MapFile;
            this.OnProgress(new ProgressEventArgs(this.progress, "Exportuji oblasti..."));
            File.Copy(input, output, true);
            this.OnProgressLog(new ProgressLogEventArgs("Zkopírován soubor " + input + " (" + output + ")"));
            this.progress += (40 / 5);
        }

        /// <summary>
        /// Exports manufacturers
        /// (this can be called AFTER <see cref="Export(string)" !)/>
        /// </summary>
        private void ExportManufacturers()
        {
            string input = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_DB" + Path.DirectorySeparatorChar + DataStorage.ManufacturerFile;
            string output = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_EXPORT" + Path.DirectorySeparatorChar + "DB" + Path.DirectorySeparatorChar + DataStorage.ManufacturerFile;
            this.OnProgress(new ProgressEventArgs(this.progress, "Exportuji výrobce..."));
            File.Copy(input, output, true);
            this.OnProgressLog(new ProgressLogEventArgs("Zkopírován soubor " + input + " (" + output + ")"));
            this.progress += (40 / 5);
        }

        /// <summary>
        /// Exports vehicles
        /// (this can be called AFTER <see cref="Export(string)" !)/>
        /// </summary>
        private void ExportVehicles()
        {
            string input = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_DB" + Path.DirectorySeparatorChar + DataStorage.VehicleFile;
            string output = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_EXPORT" + Path.DirectorySeparatorChar + "DB" + Path.DirectorySeparatorChar + DataStorage.VehicleFile;
            this.OnProgress(new ProgressEventArgs(this.progress, "Exportuji vozidla..."));
            File.Copy(input, output, true);
            this.OnProgressLog(new ProgressLogEventArgs("Zkopírován soubor " + input + " (" + output + ")"));
            this.progress += (40 / 5);
        }

        /// <summary>
        /// Exports data files
        /// (this can be called AFTER <see cref="Export(string)" !)/>
        /// </summary>
        private void ExportDataFiles()
        {
            string input = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_DB" + Path.DirectorySeparatorChar + DataStorage.DataFileFile;
            string output = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_EXPORT" + Path.DirectorySeparatorChar + "DB" + Path.DirectorySeparatorChar + DataStorage.DataFileFile;
            this.OnProgress(new ProgressEventArgs(this.progress, "Exportuji datové soubory..."));
            File.Copy(input, output, true);
            this.OnProgressLog(new ProgressLogEventArgs("Zkopírován soubor " + input + " (" + output + ")"));
            this.progress += (40 / 5);
        }

        /// <summary>
        /// Exports icons
        /// (this can be called AFTER <see cref="Export(string)"/>!)
        /// </summary>
        private void ExportIcons()
        {
            double step = 15f / (2f * this.context.FileStorage.GetAllIcons().Count());
            this.OnProgress(new ProgressEventArgs(this.progress, "Exportuji ikony..."));
            List<FileWrapper> files = new List<FileWrapper>();
            string iconIn = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_FS" + Path.DirectorySeparatorChar + "[ICONS]";
            string iconOut = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_EXPORT" + Path.DirectorySeparatorChar + "ICONS" + Path.DirectorySeparatorChar;
            int counter = 0;
            foreach(Icon icon in this.context.FileStorage.GetAllIcons())
            {
                string? iconFileIn = this.context.FileStorage.GetIconPath(icon);
                if (iconFileIn != null)
                {
                    FileInfo fi = new FileInfo(iconFileIn);
                    string iconFileOut = iconOut + Path.DirectorySeparatorChar + icon.Name;
                    File.Copy(iconFileIn, iconFileOut, true);
                    files.Add(new FileWrapper(icon.Name, iconFileIn, fi.Name));
                    this.OnProgressLog(new ProgressLogEventArgs("Zkopírován soubor " + iconFileIn + " (" + iconFileOut + ")"));
                    this.OnProgress(new ProgressEventArgs((ushort)Math.Round((double)this.progress + (counter * step)), "Exportuji ikony..."));
                    counter++;
                }
                else
                {
                    this.OnProgressLog(new ProgressLogEventArgs("CHYBA: Kopírování souboru ikony " + icon.Name + " se nezdařilo!"));
                }
            }
            XmlDocument doc = new XmlDocument();
            XmlDeclaration declaration = doc.CreateXmlDeclaration(DataStorage.XML._Version, DataStorage.XML._Charset, null);
            XmlElement? root = doc.DocumentElement;
            doc.InsertBefore(declaration, root);
            XmlElement icons = doc.CreateElement(string.Empty, "ICONS", string.Empty);
            doc.AppendChild(icons);
            foreach (FileWrapper file in files)
            {
                file.ToXml(doc, "ICON", icons);
                this.OnProgressLog(new ProgressLogEventArgs("Zapsány údaje k souboru " + file.Path));
                this.OnProgress(new ProgressEventArgs((ushort)Math.Round((double)this.progress + (counter * step)), "Exportuji ikony..."));
                counter++;
            }
            doc.Save(iconOut + "ICONS.XML");
            this.progress = (ushort)Math.Round((double)this.progress + (counter * step));
        }

        /// <summary>
        /// Exports pictures
        /// (this can be called AFTER <see cref="Export(string)"/>!)
        /// </summary>
        private void ExportPictures()
        {
            double step = 15f / (2f * this.context.FileStorage.GetPictures().Count());
            this.OnProgress(new ProgressEventArgs(this.progress, "Exportuji obrázky..."));
            List<FileWrapper> files = new List<FileWrapper>();
            string pictureIn = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_FS" + Path.DirectorySeparatorChar + "[PICTURES]";
            string pictureOut = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_EXPORT" + Path.DirectorySeparatorChar + "PICTURES" + Path.DirectorySeparatorChar;
            int counter = 0;
            foreach (Picture picture in this.context.FileStorage.GetPictures())
            {
                string? pictureFileIn = this.context.FileStorage.GetPicturePath(picture);
                if (pictureFileIn != null)
                {
                    FileInfo fi = new FileInfo(pictureFileIn);
                    string pictureFileOut = pictureOut + Path.DirectorySeparatorChar + picture.Name;
                    File.Copy(pictureFileIn, pictureFileOut, true);
                    files.Add(new FileWrapper(picture.Name, pictureFileIn, fi.Name));
                    this.OnProgressLog(new ProgressLogEventArgs("Zkopírován soubor " + pictureFileIn + " (" + pictureFileOut + ")"));
                    this.OnProgress(new ProgressEventArgs((ushort)Math.Round((double)this.progress + (counter * step)), "Exportuji obrázky..."));
                    counter++;
                }
                else
                {
                    this.OnProgressLog(new ProgressLogEventArgs("CHYBA: Kopírování souboru obrázku " + picture.Name + " se nezdařilo!"));
                }
            }
            XmlDocument doc = new XmlDocument();
            XmlDeclaration declaration = doc.CreateXmlDeclaration(DataStorage.XML._Version, DataStorage.XML._Charset, null);
            XmlElement? root = doc.DocumentElement;
            doc.InsertBefore(declaration, root);
            XmlElement pictures = doc.CreateElement(string.Empty, "PICTURES", string.Empty);
            doc.AppendChild(pictures);
            foreach (FileWrapper file in files)
            {
                file.ToXml(doc, "PICTURE", pictures);
                this.OnProgressLog(new ProgressLogEventArgs("Zapsány údaje k souboru " + file.Path));
                this.OnProgress(new ProgressEventArgs((ushort)Math.Round((double)this.progress + (counter * step)), "Exportuji obrázky..."));
                counter++;
            }
            doc.Save(pictureOut + "PICTURES.XML");
            this.progress = (ushort)Math.Round((double)this.progress + (counter * step));
        }


        /// <summary>
        /// Exports data files content
        /// (this can be called AFTER <see cref="Export(string)"/>!)
        /// </summary>
        private void ExportDataFilesContent()
        {
            double step = 15f / (2f * this.context.FileStorage.GetDataFiles().Count());
            this.OnProgress(new ProgressEventArgs(this.progress, "Exportuji obsah datových souborů..."));
            List<FileWrapper> files = new List<FileWrapper>();
            string dataFileIn = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_FS" + Path.DirectorySeparatorChar + "[DATAFILES]";
            string dataFileOut = this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_EXPORT" + Path.DirectorySeparatorChar + "DATAFILES" + Path.DirectorySeparatorChar;
            int counter = 0;
            foreach (string dataFile in this.context.FileStorage.GetDataFiles())
            {
                string? dataFileInFile = this.context.FileStorage.GetDataFilePath(dataFile);
                if (dataFileInFile != null)
                {
                    FileInfo fi = new FileInfo(dataFileInFile);
                    string dataFileOutFile = dataFileOut + Path.DirectorySeparatorChar + dataFile;
                    File.Copy(dataFileInFile, dataFileOutFile, true);
                    files.Add(new FileWrapper(dataFile, dataFileInFile, fi.Name));
                    this.OnProgressLog(new ProgressLogEventArgs("Zkopírován soubor " + dataFileInFile + " (" + dataFileOutFile + ")"));
                    this.OnProgress(new ProgressEventArgs((ushort)Math.Round((double)this.progress + (counter * step)), "Exportuji obsah datových souborů..."));
                    counter++;
                }
                else
                {
                    this.OnProgressLog(new ProgressLogEventArgs("CHYBA: Kopírování obsahu datového souboru " + dataFile + " se nezdařilo!"));
                }
            }
            XmlDocument doc = new XmlDocument();
            XmlDeclaration declaration = doc.CreateXmlDeclaration(DataStorage.XML._Version, DataStorage.XML._Charset, null);
            XmlElement? root = doc.DocumentElement;
            doc.InsertBefore(declaration, root);
            XmlElement datafiles = doc.CreateElement(string.Empty, "DATAFILES", string.Empty);
            doc.AppendChild(datafiles);
            foreach (FileWrapper file in files)
            {
                file.ToXml(doc, "DATAFILE", datafiles);
                this.OnProgressLog(new ProgressLogEventArgs("Zapsány údaje k souboru " + file.Path));
                this.OnProgress(new ProgressEventArgs((ushort)Math.Round((double)this.progress + (counter * step)), "Exportuji obsah datových souborů..."));
                counter++;
            }
            doc.Save(dataFileOut + "DATAFILES.XML");
            this.progress = (ushort)Math.Round((double)this.progress + (counter * step));
        }

        /// <summary>
        /// Finishes export of data
        /// (this can be as LAST call of any export function)
        /// </summary>
        private void FinishExport()
        {
            this.progress = 90;
            this.OnProgress(new ProgressEventArgs(this.progress, "Dokončuji export dat..."));
            if (File.Exists(this.OutputPath))
            {
                File.Delete(this.OutputPath);
                this.OnProgressLog(new ProgressLogEventArgs("Smazán soubor " + this.OutputPath));
            }
            ZipFile.CreateFromDirectory(this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_EXPORT", this.OutputPath);
            this.OnProgressLog(new ProgressLogEventArgs("Vytvořen soubor " + this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_EXPORT" + Path.DirectorySeparatorChar + this.OutputPath));
            this.progress = 95;
            Directory.Delete(this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_EXPORT", true);
            this.OnProgress(new ProgressEventArgs(this.progress, "Dokončuji export dat..."));
            this.OnProgressLog(new ProgressLogEventArgs("Smazán adresář " + this.context.Configuration.TempDir + Path.DirectorySeparatorChar + "_EXPORT"));
            this.progress = 100;
            this.OnProgress(new ProgressEventArgs(this.progress, "Hotovo"));
            this.OnProgressLog(new ProgressLogEventArgs("Hotovo"));
            this.OnProcessDone();
        }

        /// <summary>
        /// Gets list of actions needed to successfull export
        /// </summary>
        /// <returns>List with all necessary actions needed to successfull export</returns>
        public List<Action> GetExportSequence()
        {
            List<Action> reti = new List<Action>();
            reti.Add(new Action(() => { this.Export(); }));
            reti.Add(new Action(() => { this.ExportInformationSystems(); }));
            reti.Add(new Action(() => { this.ExportMaps(); }));
            reti.Add(new Action(() => { this.ExportManufacturers(); }));
            reti.Add(new Action(() => { this.ExportVehicles(); }));
            reti.Add(new Action(() => { this.ExportDataFiles(); }));
            reti.Add(new Action(() => { this.ExportIcons(); }));
            reti.Add(new Action(() => { this.ExportPictures(); }));
            reti.Add(new Action(() => { this.ExportDataFilesContent(); }));
            reti.Add(new Action(() => { this.FinishExport(); }));
            return reti;
        }
    }
}
